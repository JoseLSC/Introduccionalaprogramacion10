
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float ft,inch,yd,cm,m;
  printf("Introduzca la cantidad en pies:\n");
  scanf("%f",&ft);
  
  inch=12*ft;
  yd=3*ft;
  cm=ft/0.0328;
  m=ft/3.28;
  printf("Los valores son:\n %f pulgadas\n %f yardas\n %f centimetros\n %f metros\n",inch,yd,cm,m);
  system("PAUSE");	
  return 0;
}

