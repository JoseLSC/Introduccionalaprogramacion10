#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main(int argc, char *argv[])
{
  float h,P,p,v,d;
  char liquido;
  int pagua,pdiesel;
  pagua=1000;
  pdiesel=820;
  float g;
  g=9.81;
  
  printf("Introduzca el liquido en tratamiento, escribiendo 'a' si es agua o 'd'\n si es diesel\n");
  scanf("%c",&liquido);
  printf("Introduzca la presion hidrostatica(bar) del fluido en la base del pozo:\n");
  scanf("%f",&P);
  printf("Introduzca el diametro del pozo:\n");
  scanf("%f",&d);
  
  p=(liquido=='a')?pagua:pdiesel;
  h=P/(p*g);
  v=(PI*d*d/4)*h;
  printf("El volumen del liquido es:%f\n",v);


  system("PAUSE");	
  return 0;
}

