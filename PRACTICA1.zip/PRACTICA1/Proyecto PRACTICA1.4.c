#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{

  int segt,seg,min,hr;
  printf("Introduzca la cantidad en segundos para obtener\n su equivalente en minutos segundos:\n");
  scanf("%i",&segt);
  hr=(segt/60<60)?0:(segt/60)/60;
  min=(segt/60<60)?segt/60:(segt/60)%60;
  seg=segt%60;
  
  printf("segundos:%i\nminutos:%i\nhoras:%i\n",seg,min,hr);
 
  system("PAUSE");	
  return 0;
}

