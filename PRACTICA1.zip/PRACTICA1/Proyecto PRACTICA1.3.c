#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.1416
int main(int argc, char *argv[])
{
  float r,h,g,a,v;
  printf("Introduzca el radio y la altura del cono:\n");
  scanf ("%f %f",&r,&h);
  
  g=_hypot(r,h);
  a=(2*PI*r*g)/2+PI*r*r;
  v=PI*r*r*h/3;
  printf("El area lateral mas el area de la base del cono es:\n%f\n y su volumen es:\n%f",a,v);
  
  
  system("PAUSE");	
  return 0;
}

