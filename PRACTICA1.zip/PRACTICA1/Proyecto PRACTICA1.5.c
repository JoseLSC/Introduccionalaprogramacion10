#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float grados;
  char letra;
  printf("Introduzca la temperatura en grados celsius o farenheit\n");
  scanf("%f%c",&grados,&letra);
  
  
grados=(letra=='c')?grados*9/5+32:(grados-32)*5/9;
  (letra=='c')?printf("Los grados son:%.3fF\n",grados):printf("Los grados son:%.3fC\n",grados);
  
 
  

  system("PAUSE");	
  return 0;
}

