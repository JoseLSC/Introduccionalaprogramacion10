#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,y,a,b,res,f;
   printf("Realizaremos la operacion x mas y al cuadrado por a menos b\n");
  printf("Establezca el valor x\nx=");
  scanf("%i",&x);
  printf("Establezca el valor y\ny=");
  scanf("%i",&y);
 printf("Establezca el valor a\na=");
   scanf("%i",&a);
   printf("Establezca el valor b\nb=");
   scanf("%i",&b);
   
  res= (x+y)*(x+y)*(a-b);
  
  
  printf("El resultado de la operacion x mas y al cuadrado por a menos b es:%i\n",res);
 
  system("PAUSE");	
  return 0;
}

